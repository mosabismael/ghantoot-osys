<?php
	
	//page settings
	$no_session = false;
	$main_pointer = '';
	$main_pointer = '../../';
	require_once($main_pointer.'bootstrap/app_config.php');
	require_once($main_pointer.'bootstrap/chk_log_user.php');
	try{
		
	if( isset($_POST['client_id']) &&
		isset($_POST['project_notes'])
		){
			
			
			$project_id = 0;
			$client_id = ( int ) test_inputs($_POST['client_id']);
			
			$created_date = date("Y-m-d");
			$project_status = "draft";
			
			$project_notes = "";
			if( isset($_POST['project_notes']) ){
				$project_notes = test_inputs( $_POST['project_notes'] );
			}
			
	$qu_sales_projects_ins = "INSERT INTO `sales_projects` (
						`created_date`, 
						`project_notes`, 
						`client_id`, 
						`employee_id`, 
						`project_status` 
					) VALUES (
						'".$created_date."', 
						'".$project_notes."', 
						'".$client_id."', 
						'".$EMPLOYEE_ID."', 
						'".$project_status."' 
					);";
					
			$insertStatement = mysqli_prepare($KONN,$qu_sales_projects_ins);
			
			mysqli_stmt_execute($insertStatement);
			
			$project_id = mysqli_insert_id($KONN);
			if( $project_id != 0 ){
				
				if( insert_state_change($KONN, 'Project_added', $project_id, "sales_projects", $EMPLOYEE_ID) ){
					
					die('1|projects_list.php?added=1');
					
				} else {
					die('0| State Error 035532');
				}
				
				
				
			}
			
			
			
			
			
			} else {
			die('0|7wiu');
		}
	}
	catch(Exception $e){
		if ( is_resource($KONN)) {
			mysqli_close($KONN);
		}
	}
	finally{
		if ( is_resource($KONN)) {
			mysqli_close($KONN);
		}
	}
?>
